# Utility functions and classes
